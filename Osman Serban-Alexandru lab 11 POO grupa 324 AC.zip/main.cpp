#include <iostream>
#include <vector>

using namespace std;

template <typename T>

class Stack{

public:

    vector <T> vec;

    bool Empty(){
        return vec.empty();

    }

    void push(const T &item){
        vec.push_back(item);
        cout<<"Elementul a fost adaugat"<<endl;
    }

    T &top(){

        return vec.back();
    }

    void pop(){

        vec.pop_back();
        cout<<"Elementul a fost sters"<<endl;

    }
};
void afisare()
{
    Stack <int> a;
    int x,y=1;
    while(y)
    {
        cout<<"------MENIU------\nAlegeti una dintre urmatoarele optiuni:\n1.Adauga un element la stiva\n2.Sterge un element din stiva\n3.Verifica daca stiva este goala\n4.Returneaza referinta ultimului element adaugat\n5.Afisare\nOptiunea: ";
         cin>>y;
          switch(y){
        case 1: {
            cout<<"Element:";
            cin>>x;
            a.push(x);
            break;
        }
        case 2:{
            if(a.Empty() == false)
            {
                a.pop();
            }
            else
                cout<<"Stiva este goala"<<endl;
             break;
        }
        case 3:{
             if(a.Empty() == true)
                cout<<"Stiva este goala"<<endl;
             else
                cout<<"Stiva nu este goala"<<endl;
             break;
        }
        case 4:{
            cout<<"Referinta catre cel mai recent element adaugat este: "<<a.top()<<endl;
            break;
        }
        case 5: {
            for(int i = 0; i < a.vec.size(); i++)
                cout<<a.vec[i]<<" ";
            cout<<endl;
            break;
        }

    }
}
}
int main()
{
    afisare();
    return 0;
}


